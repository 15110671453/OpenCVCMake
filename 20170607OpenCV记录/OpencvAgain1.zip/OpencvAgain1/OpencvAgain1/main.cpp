//
//  main.cpp
//  OpencvAgain1
//
//  Created by admindyn on 2017/5/11.
//  Copyright © 2017年 admindyn. All rights reserved.
//

#include "ServerMacKQueue.hpp"
#include "SocketMac.hpp"
#include "SocketMacClient.hpp"
#include "NodeManager.hpp"
#include "PointManager.hpp"
#include "StudentManager.hpp"
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
//#include <opencv2/imgproc/imgproc_c.h>
/*opencv对视频操作头文件*/

#include <opencv2/video/video.hpp>
#include <vector>

#include <iostream>
using namespace std;
using namespace cv;
void macXcodeShowImage();
void macXcodeShowImage2();
void macXcodeImageFuShi();
void macXcodeImageFuShi2();
void  macXcodeImageMoHu();
void macXcodeVideoCapture();
void  macXcodeImageBianYuanJiance1();
//创建alpha通道图片
void macXcodeImageAlphaMat();
void  macXcodeImageHunHe();


#define WINDOW_NAME "xianxinghunhe"
//-------滑动条线性混合1分割线开始------------
//全局变量的声明
const int g_nMaxAlphaValue = 100;//Alpha值的最大值
int g_nAlphaValueSlider;//滑动条对应的变量
double g_dAlphaValue;
double g_dBetaValue;

 char TrackbarName[50];

//声明存储图像的变量
//-------滑动条线性混合1分割线结束------------
void  macXcodeHuaDongTiao();



Mat g_srcImage1;
Mat g_srcImage2;
Mat g_dstImage;

//第十个程序
void  on_MouseHandle(int event,int x, int y , int flags, void * param);
void DrawRectangle(Mat & img, Rect box);

void  showHelpText();
Rect g_rectangle;
bool g_bDrawingBox = false;//是否进行绘制
RNG g_rng(12345);
//第十个程序
void  macXcodeMouseClick();
int main(int argc, const char * argv[]) {
    //argc arguments count
    /*整数 用来统计 运行程序时发送给main函数的命令行参数的个数*/
    //argv字符串数组 用来存放指向字符参数的指针数组
     printf("argc >>>%d\n",argc);
    const char* imageName =  argv[0];
    printf("argv1 >>>%s\n",imageName);
//    StudentManager* manager= new StudentManager;
//    manager->mainPrint();
//    PointManager* manager1 = new PointManager;
//    manager1->mainPrint();
//    NodeManager* manager2 = new NodeManager;
//    manager2->mainPrintf();
//    SocketMac* macserver= new SocketMac;
//    macserver->readySocket();
    
    ServerMacKQueue* server=new ServerMacKQueue;
    server->testKQueueServer();
//    SocketMacClient* macclient = new SocketMacClient;
//    macclient->readySocket();
//    macXcodeMouseClick();
    return 0;
}

void  on_MouseHandle(int event,int x, int y , int flags, void * param){

    Mat& image = *(Mat*) param;
    
    switch (event) {
        case EVENT_MOUSEMOVE:
        {
            if (g_bDrawingBox) {
                //如果是否进行绘制的标识符为真 则记录下长和宽到RECT型变量中
                g_rectangle.width=x-g_rectangle.x;
                g_rectangle.height=y-g_rectangle.y;
            }
        }
            break;
            
        case EVENT_LBUTTONDOWN  :{
            g_bDrawingBox=true;
            g_rectangle=Rect(x,y,0,0);
            //记录起始点
        }
             break;
            
        case EVENT_LBUTTONUP:{
            g_bDrawingBox = false;
            //置标识符为false
            
            //对宽和高小于0的处理
            
            if (g_rectangle.width<0)  {
                
                g_rectangle.x += g_rectangle.width;
                g_rectangle.width *= -1;
                
                
            }
            if (g_rectangle.height<0) {
                g_rectangle.y += g_rectangle.height;
                g_rectangle.height *= -1;
            }
            //调用函数 进行绘制
            DrawRectangle(image, g_rectangle);
            
            
            
        }
            break;
        default:
            break;
    }
    
}
void DrawRectangle(Mat & img, Rect box){

    rectangle(img, box.tl(), box.br(), Scalar(g_rng.uniform(0,255),g_rng.uniform(0,255),g_rng.uniform(0,255)));
    
    
}

void  showHelpText(){

}
//创建透明的alpha通道函数
void  createAlphaMat(Mat &mat){
    for (int i=0; i<mat.rows; ++i) {
        for (int j=0; j<mat.cols; ++j) {
            Vec4b& rgba = mat.at<Vec4b>(i,j);
            rgba[0]=UCHAR_MAX;
            rgba[1]=saturate_cast<uchar>((float (mat.cols - j))/((float)mat.cols)*UCHAR_MAX);
            rgba[2]=saturate_cast<uchar>((float (mat.rows - j))/((float)mat.rows)*UCHAR_MAX);
            
            rgba[3]=saturate_cast<uchar>(0.5*(rgba[1]+rgba[2]));
        }
    }

}
   //响应滑动条的回调函数

void on_Trackbar(int ,void *){
//求出当前alpha值相对于最大值的比例
    g_dAlphaValue=(double)g_nAlphaValueSlider/g_nMaxAlphaValue;
    //则beta值为1减去alpha值
    g_dBetaValue=(1.0-g_dAlphaValue);
    
    //根据alpha与beta值进行线性混合
    
    addWeighted(g_srcImage1, g_dAlphaValue, g_srcImage2, g_dBetaValue, 0.0, g_dstImage);
     sprintf(TrackbarName, "AlphaValue:%d/%d",g_nMaxAlphaValue,g_nAlphaValueSlider);
    imshow(WINDOW_NAME, g_dstImage);
    
}


//Opencv第十个程序 创建滑动条
/*
 opencv
 并没有实现按钮的功能 所以很多时候 我们可以用仅含0-1的滑动条来实现按钮的按下与谈起效果
 */
void  macXcodeMouseClick(){
    g_rectangle = Rect(-1,-1,0,0);
    
    Mat srcImage(600,800,CV_8UC3), tempImage;
    
    srcImage.copyTo(tempImage);
    
    g_rectangle = Rect(-1,-1,0,0);
    srcImage =Scalar::all(0);
    
    //设置鼠标操作回调函数
    
    namedWindow(WINDOW_NAME);
    
    setMouseCallback(WINDOW_NAME,on_MouseHandle,(void*)&srcImage);
    
    while (1) {
        //复制源图到临时变量
        srcImage.copyTo(tempImage);
        
        if (g_bDrawingBox) {
            //当进行绘制标示符为真 则进行绘制
            DrawRectangle(tempImage, g_rectangle);
        }
        imshow(WINDOW_NAME, tempImage);
        
        if (waitKey(10)==27) {
            //按下ESC键 程序退出
            break;
        }
        
    }
    
}


//Opencv第九个程序 创建滑动条
/*
 opencv
 并没有实现按钮的功能 所以很多时候 我们可以用仅含0-1的滑动条来实现按钮的按下与谈起效果
 */
void  macXcodeHuaDongTiao()
{
    /*滑动条在线性混合中应用*/
//#define WINDOW_NAME "xianxinghunhe";
//    
//    //全局变量的声明
//    const int g_nMaxAlphaValue = 100;//Alpha值的最大值
//    int g_nAlphaValueSlider;//滑动条对应的变量
//    double g_dAlphaValue;
//    double g_dBetaValue;
//    
//    //声明存储图像的变量
//    
//    
//    Mat g_srcImage1;
//    Mat g_srcImage2;
//    Mat g_dstImage;
    
    //响应滑动条的回调函数
    
    
    //
    g_srcImage1= imread("/Users/admindyn/Desktop/images/testimage1.jpg");
    g_srcImage2= imread("/Users/admindyn/Desktop/images/testimage2.jpg");
    
    if (!g_srcImage1.data) {
        printf("读取第一幅图片错误，请确定图片存在\n");
    }
    if (!g_srcImage2.data) {
        printf("读取第二幅图片错误，请确定图片存在\n");
    }
    //设置滑动条初始值70
    
    g_nAlphaValueSlider=70;
    
    //创建窗体
    namedWindow(WINDOW_NAME,1);
    
    //在创建的窗体中创建一个滑动条控件
    
   
    
    sprintf(TrackbarName, "AlphaValue:%d/%d",g_nMaxAlphaValue,g_nAlphaValueSlider);
    //opencv库函数 用于创建滑动条
    createTrackbar(TrackbarName, WINDOW_NAME, &g_nAlphaValueSlider, g_nMaxAlphaValue,on_Trackbar);
    
    //结果在回调函数中显示
 
    on_Trackbar(g_nAlphaValueSlider, 0);
       g_nAlphaValueSlider= getTrackbarPos(TrackbarName, WINDOW_NAME);
    
    waitKey();
    
}

//Opencv第八个程序 创建混合图像

void macXcodeImageHunHe(){
    Mat girl = imread("/Users/admindyn/Desktop/images/testimage1.jpg");
    
    namedWindow("dongmantu");
    
    imshow("dongmanyuantu", girl);
    //图像的混合
    
    Mat image =imread("/Users/admindyn/Desktop/images/testimage1.jpg");
    
    Mat logo = imread("/Users/admindyn/Desktop/images/gongzhonghao.jpg");
    namedWindow("yuantu2");
    imshow("yuantu2", image);
    namedWindow("logo1");
    imshow("logo1", logo);
    
    //定义一个Mat类型 用于存放 图像的ROI
    
    Mat imageROI;
    //指定图像的感兴趣区域，imageROI的数据与源图像image共享存储区，所以此后在imageROI上的操作也会作用在源图像image上
    int col=image.cols;
    int row=image.rows;
    
    /*
     注意这里的 image 必须大图logo 必须小图 负责 无法运行 报错
     */
    imageROI = image(Rect(20,20,logo.cols,logo.rows));
    
    //方法二
//   imageROI = image(Range(20,20+logo.rows),Range(20,20+logo.cols));
    //将logo添加到原图上
    
    addWeighted(imageROI, 0.5, logo, 0.3, 0., imageROI);
    
    namedWindow("hunhehoutu11");
    
    imshow("hunhehoutu11", image);
    
    imwrite("由imwrite生成的图片.jpg", image);
    
    waitKey();
    
    
    
}

//Opencv第七个程序 创建透明的alpha通道图
void macXcodeImageAlphaMat()
{
    //创建带Alpha通道的Mat
    Mat mat(480, 640, CV_8UC4);
    createAlphaMat(mat);
    
    vector<int>compression_params;
    
    compression_params.push_back(IMWRITE_PNG_COMPRESSION);
    
    compression_params.push_back(9);
    
    try {
        imwrite("touming.png", mat,compression_params);
        imshow("shengcheng", mat);
        fprintf(stdout, "PNG图片文件的alpha数据保存完毕~\n可以在工程目录下查看imwrite函数生成的图片\n");
        waitKey();
    } catch (runtime_error&ex) {
        fprintf(stderr, "图像转换成PNG格式发生错误:%s\n",ex.what());
       
    }
    
    
}
//Opencv第六个程序 视频的操作-摄像头采集
void macXcodeVideoCapture()
{
//     namedWindow("shexiangtou");
//    //从摄像头读入视频
//    VideoCapture capture(0);
//    capture.open(0);
//    capture.set( CV_CAP_PROP_FRAME_WIDTH, 640);
//      capture.set( CV_CAP_PROP_FRAME_HEIGHT, 480);
//    if (!capture.isOpened()) {
//        printf("无法打开摄像头\n");
//        getchar();
//        return;
//    }
//    //循环显示每一帧
//    while (1) {
//        //定一个存储图像数据结构
//        //定义一个Mat变量 用于存储每一帧图像
//        Mat frame;
//        //读取当前帧
//        capture>>frame;
//        //显示当前帧
//        imshow("captureVideo", frame);
//        //延时30 毫秒
//        waitKey(30);
//        
//    }
    
    cvNamedWindow("Camera" , CV_WINDOW_AUTOSIZE );
    
    CvCapture* capture = cvCreateCameraCapture(CV_CAP_AVFOUNDATION);
    
    assert(capture != NULL);
    
    IplImage *frame = 0;
    frame = cvQueryFrame(capture);
    
    IplImage *frame_edge = cvCreateImage(cvGetSize(frame),
                                         IPL_DEPTH_8U,
                                         1);
    while(1)
    {
        frame = cvQueryFrame(capture);
        if(!frame) break;
        
        cvConvertImage(frame,frame_edge,0);
        frame = cvCloneImage(frame_edge);
        
//        frame_edge = doCanny(frame_edge,70,90,3);
        
        cvShowImage("Camera",frame_edge);
        char c = cvWaitKey(15);
        if(c == 27)  break;
    }
    
    cvReleaseCapture(&capture);
    cvReleaseImage( &frame_edge );
    cvReleaseImage( &frame);
    
}
//Opencv第五个程序 视频的操作-视频文件
/*
 Opencv 2 对视频操作 使用VideoCapture类
 作用是 从视频文件 或者 摄像头 捕获视频 并显示出来
 */
 void macXcodeVideoFile()
{

}


//Opencv第四个程序 canny边缘检测 图像
/*
 Opencv 载入图像 并将其转成灰度图 在用blur函数进行图像模糊以降噪 
 然后用canny进行边缘检测  最后显示
 */

void  macXcodeImageBianYuanJiance1()
{
    //载入原图
    //Mat为图像存储数据结构Mat类
    Mat srcImage =imread("/Users/admindyn/Desktop/images/testimage1.jpg");
    //显示原图
    namedWindow("xiaochengxu3");
    //不要使用中文
    imshow("show-yuantu", srcImage);
    
    Mat edge,grayImage;//参数定义
    //将原图转换为灰度图像
    cvtColor(srcImage, grayImage, CV_BGR2GRAY);
     imshow("huidutu", grayImage);
    //想使用3x3内核来降噪
    
    blur(grayImage, edge, Size(3,3));
    
     imshow("jiangzao", edge);
    
    //运行Cannt算子

    Canny(edge, edge, 3, 9, 3);
    
    imshow("bianyuanjiance", edge);
    waitKey(0);
    
    

}

//Opencv第三个程序 图像模糊
/*
 Opencv使用均值滤波blur函数 对图像进行均值滤波 模糊图像效果
 */

void  macXcodeImageMoHu()
{
    //载入原图
       //Mat为图像存储数据结构Mat类
    Mat srcImage =imread("/Users/admindyn/Desktop/images/testimage1.jpg");
    //显示原图
    namedWindow("xiaochengxu2");
    //不要使用中文
    imshow("show-yuantu", srcImage);
    
    //进行均值滤波操作
    
    Mat dstImage;
    blur(srcImage, dstImage, Size(7,7));
    imshow("mohutu", dstImage);
    waitKey(0);
}

//Opencv第二个程序 图像腐蚀
/*
 opecv 实现最基本的形态学运算之一 腐蚀
 即用图像中暗色部分 腐蚀掉 图像中的高亮部分
 使用opencv的 erode 函数 对图像实现腐蚀效果
 
 */

void macXcodeImageFuShi2()
{
    //载入原图
       //Mat为图像存储数据结构Mat类
    Mat srcImage =imread("/Users/admindyn/Desktop/images/testimage1.jpg");
    //显示原图
    namedWindow("xiaochengxu1");
    //不要使用中文
    imshow("show-yuantu", srcImage);
    //进行腐蚀操作
    //getStructuringElement 指定腐蚀 时 每个腐蚀块的大小 不建议设置太大 否则 腐蚀效果看不出来
    Mat element = getStructuringElement(MORPH_RECT, Size(15,15));
    Mat dstImage;
    
    erode(srcImage, dstImage, element);
    //先腐蚀再反转
     flip(dstImage,dstImage, 0);
    //显示效果图
    
    
    //不要使用中文
    imshow("xiaoguotu", dstImage);
    
    waitKey(0);
}

void macXcodeImageFuShi()
{
    //载入原图
       //Mat为图像存储数据结构Mat类
    Mat srcImage =imread("/Users/admindyn/Desktop/images/testimage1.jpg");
    //显示原图
    namedWindow("xiaochengxu1");
      //不要使用中文
    imshow("show-yuantu", srcImage);
    //进行腐蚀操作
    //getStructuringElement 指定腐蚀 时 每个腐蚀块的大小 不建议设置太大 否则 腐蚀效果看不出来
    Mat element = getStructuringElement(MORPH_RECT, Size(15,15));
    Mat dstImage;
    
    erode(srcImage, dstImage, element);
    
    //显示效果图
    
    
      //不要使用中文
   imshow("xiaoguotu", dstImage);
    
    waitKey(0);
}

//Opecv第一个程序 图像显示
void macXcodeShowImage()
{
       //Mat为图像存储数据结构Mat类
    Mat image = imread("/Users/admindyn/Desktop/images/gongzhonghao.jpg") ; //读取图片
    if(!image.data)                  // data指向已分配内存块的指针
    {
        cout << "fail to load image" << endl;
    }
    cout << "image size: " << image.size().height << "," << image.size().width << endl; //size()返回的是一个结构体
    namedWindow("show");
  
    imshow("show-yuantu", image);       // 显示图片
    imwrite("/Users/admindyn/Desktop/images/gongzhonghao3.jpg", image);
    Mat result;
    flip(image,result, 0);
    namedWindow("result",0);
    imshow("result", result);
    //等待6000ms后 窗口自动关闭 其实也是程序自动停止
    waitKey(6000);
   
}


void macXcodeShowImage2()
{
       //Mat为图像存储数据结构Mat类
    Mat image = imread("/Users/admindyn/Desktop/images/gongzhonghao.jpg") ; //读取图片
    if(!image.data)                  // data指向已分配内存块的指针
    {
        cout << "fail to load image" << endl;
    }
    cout << "image size: " << image.size().height << "," << image.size().width << endl; //size()返回的是一个结构体
    namedWindow("show");
    imshow("show", image);       // 显示图片
    imwrite("/Users/admindyn/Desktop/images/gongzhonghao3.jpg", image);
    Mat result;
    flip(image,result, 0);
    namedWindow("result",0);
    imshow("result", result);
    //等待任意键按下 窗口自动关闭 其实也是程序自动停止
    waitKey(0);
    
}

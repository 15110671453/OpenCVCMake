//
//  Student.cpp
//  OpencvAgain1
//
//  Created by admindyn on 2017/6/7.
//  Copyright © 2017年 admindyn. All rights reserved.
//

#include "Student.hpp"



    

    /*无参构造参数*/
    Student::Student()
    {
        this->num =0;
    
        this->score=0;
    }
    Student::Student(int num,char* name,int score)
    {
        this->num =0;
        
        this->score=0;
    }
    /*比较自身成绩与最高分 在主函数内使用switch 语句处理当前的返回值*/
    int Student:: compare(float max){
        if (this->score>max) {
            return 1;
        }else if(this->score ==max){
            return 2;
        }
        return 3;
    }



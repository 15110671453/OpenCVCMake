//
//  Student.hpp
//  OpencvAgain1
//
//  Created by admindyn on 2017/6/7.
//  Copyright © 2017年 admindyn. All rights reserved.
//

#ifndef Student_hpp
#define Student_hpp

#include <stdio.h>
class Student {
    /*类成员变量*/
public:
    int num;//学号
    int score;//成绩
    char name[20];//学名
    
public:
    /*无参构造参数*/
    Student();
    Student(int num,char* name,int score);
    /*比较自身成绩与最高分 在主函数内使用switch 语句处理当前的返回值*/
    int compare(float max);
};
#endif /* Student_hpp */

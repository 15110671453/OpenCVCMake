//
//  NodeManager.hpp
//  OpencvAgain1
//
//  Created by admindyn on 2017/6/7.
//  Copyright © 2017年 admindyn. All rights reserved.
//

#ifndef NodeManager_hpp
#define NodeManager_hpp

#include <stdio.h>

class NodeManager{
  
public:
    NodeManager();
    void mainPrintf();
    
};

#endif /* NodeManager_hpp */

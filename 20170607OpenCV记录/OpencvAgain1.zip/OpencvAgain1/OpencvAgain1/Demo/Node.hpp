//
//  Node.hpp
//  OpencvAgain1
//
//  Created by admindyn on 2017/6/7.
//  Copyright © 2017年 admindyn. All rights reserved.
//

#ifndef Node_hpp
#define Node_hpp

#include <stdio.h>


class Node {

private:
    int data;
    
    Node* next;
  
public:

    /*构造方法创造离散节点*/
    Node();
    Node(int data);
    /*向链表尾加入节点*/
    static void AddNode(int data);
    /**/
    static void AddNode(Node* node);
    /*  根据数据内容删除节点*/
    static bool DeleteNodes(int data);
    static void GetNodesMessage();
    
    

};

#endif /* Node_hpp */

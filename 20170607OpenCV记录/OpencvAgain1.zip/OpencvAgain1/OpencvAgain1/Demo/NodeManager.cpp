//
//  NodeManager.cpp
//  OpencvAgain1
//
//  Created by admindyn on 2017/6/7.
//  Copyright © 2017年 admindyn. All rights reserved.
//

#include "Node.hpp"
#include "NodeManager.hpp"

NodeManager::NodeManager()
{

}

void NodeManager::mainPrintf()
{
    
    
    Node::GetNodesMessage();
    printf("添加节点\n");
    
    Node* n1 =new Node(4);
    Node* n2 = new Node(*n1);
    Node::AddNode(n1);
    Node::AddNode(5);
    Node::AddNode(6);
     Node::AddNode(7);
     Node::AddNode(8);
     Node::AddNode(n2);
    Node::GetNodesMessage();
    printf("删除数据为4的节点\n");
    
    Node::DeleteNodes(4);
    Node::GetNodesMessage();


}

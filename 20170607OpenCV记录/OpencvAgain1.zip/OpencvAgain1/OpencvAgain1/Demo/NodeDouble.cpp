//
//  NodeDouble.cpp
//  OpencvAgain1
//
//  Created by admindyn on 2017/6/7.
//  Copyright © 2017年 admindyn. All rights reserved.
//

#include "NodeDouble.hpp"

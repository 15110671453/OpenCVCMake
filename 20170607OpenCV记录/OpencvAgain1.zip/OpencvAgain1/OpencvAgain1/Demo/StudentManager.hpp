//
//  StudentManager.hpp
//  OpencvAgain1
//
//  Created by admindyn on 2017/6/7.
//  Copyright © 2017年 admindyn. All rights reserved.
//

#ifndef StudentManager_hpp
#define StudentManager_hpp

#include <stdio.h>
class StudentManager
{
public:
    StudentManager();
    void mainPrint();

};
#endif /* StudentManager_hpp */

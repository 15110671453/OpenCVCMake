//
//  PointManager.hpp
//  OpencvAgain1
//
//  Created by admindyn on 2017/6/7.
//  Copyright © 2017年 admindyn. All rights reserved.
//

#ifndef PointManager_hpp
#define PointManager_hpp

#include <stdio.h>

class PointManager{

public:
    PointManager();
    
    void mainPrint();
    

};

#endif /* PointManager_hpp */

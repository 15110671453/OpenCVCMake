//
//  SocketMacClient.hpp
//  OpencvAgain1
//
//  Created by admindyn on 2017/6/7.
//  Copyright © 2017年 admindyn. All rights reserved.
//

#ifndef SocketMacClient_hpp
#define SocketMacClient_hpp

#include <string.h>
#include <stdio.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
class SocketMacClient
{
public:
    SocketMacClient();
  
    struct sockaddr_in server_addr;
    void readySocket();
};
#endif /* SocketMacClient_hpp */

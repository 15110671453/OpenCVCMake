//
//  StudentManager.cpp
//  OpencvAgain1
//
//  Created by admindyn on 2017/6/7.
//  Copyright © 2017年 admindyn. All rights reserved.
//
#include "Student.hpp"
#include "StudentManager.hpp"




StudentManager::StudentManager()
    {
    }
void StudentManager::mainPrint()
    {
        int n =0;
        do{
            printf("请输入学生人数(1~30之间):\n");
            scanf("%d",&n);
        }while (!n>0||n>30) ;
        /*定义学生类数组记录并比较成绩*/
        Student* pStudent = new Student[n];
        
        printf("请按照\"学号,成绩,姓名\"的格式输入学生信息:\n");
        
        for (int i=0;i<n;i++ ) {
            printf("请输入第%d个学生的信息:\n",i+1);
            scanf("%d,%d,%s",&pStudent[i].num,&pStudent[i].score,&pStudent[i].name);
        }
        
        Student* pStudents_M = new Student[1];
        int max_score =0;
        int max_count =1;
        /*将最高成绩学生放入记录数组*/
        
        for (int i=0; i<n; i++) {
            switch (pStudent[i].compare(max_score)) {
                case 1:
                    max_score = pStudent[i].score;
                    /* 刷新最高成绩学生信息*/
                    max_count = 1;
                    if (pStudents_M!=NULL) {
                        delete [] pStudents_M;
                    }
                    pStudents_M = new Student[1];
                    pStudents_M[0]=pStudent[i];
                    break;
            case 2:
                    /*将成绩最高者的数据保存起来*/
                    Student* pTemp = pStudents_M;
                    /*刷新最高成绩学生的信息*/
                    pStudents_M= new Student[++max_count];
                    /*将成绩最高者的数据转移到新开辟的数组空间中，新数组空间中，新数组空间比原来的数组容量多一个*/
                    
                    for (int j=0; j<max_count-1; j++) {
                        pStudents_M[j]= pTemp[j];
                        
                    }
                    pStudents_M[max_count-1]=pStudent[i];
                    /*回收内存*/
                    delete [] pTemp;
                    break;
                 
            }
        }
        /*输出成绩最高者的信息*/
        
        printf("当前最高成绩为:%d,成绩最高者:\n",max_score);
        for (int i=0; i<max_count; i++) {
            printf("%d,%s,%d\n",pStudents_M[i].num,pStudents_M[i].name,pStudents_M[i].score);
        }
        
        /*回收内存*/
        
        delete [] pStudent;
        delete [] pStudents_M;
        
        /*
         请输入学生人数(1~30之间):
         3
         请按照"学号,成绩,姓名"的格式输入学生信息:
         请输入第1个学生的信息:
         11,15,dyn
         请输入第2个学生的信息:
         123,146,ddn
         请输入第3个学生的信息:
         22,88,yyy
         当前最高成绩为:146,成绩最高者:
         123,ddn,146
         */
        
        
    }



//
//  Point.cpp
//  OpencvAgain1
//
//  Created by admindyn on 2017/6/7.
//  Copyright © 2017年 admindyn. All rights reserved.
//

#include <math.h>
#include "Point.hpp"

Point::Point(){
    this->x =0;
    this->y =0;
}
Point::Point(double x,double y)
{
    this->x=x;
    this->y=y;
}

double Point::getDistance(Point& p){
    double dX = this->x-p.x;
    double dY = this->y-p.y;
    return sqrt(dX*dX+dY*dY);
}

//
//  PointManager.cpp
//  OpencvAgain1
//
//  Created by admindyn on 2017/6/7.
//  Copyright © 2017年 admindyn. All rights reserved.
//

#include "Point.hpp"
#include "PointManager.hpp"

PointManager::PointManager()
{
}

void PointManager::mainPrint()
{
    Point a;
    Point b;
    printf("请输入a点坐标:\n");
    
    scanf("%lf,%lf",&a.x,&a.y);
    printf("请输入b点坐标:\n");
    
    scanf("%lf,%lf",&b.x,&b.y);
    
    double distance = a.getDistance(b);
    
    printf("a,b两点的距离为:%f\n",distance);
    
}

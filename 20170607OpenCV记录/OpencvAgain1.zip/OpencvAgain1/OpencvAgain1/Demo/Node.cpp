//
//  Node.cpp
//  OpencvAgain1
//
//  Created by admindyn on 2017/6/7.
//  Copyright © 2017年 admindyn. All rights reserved.
//

#include "Node.hpp"

static Node* pHead=NULL;/*链表头*/
static Node* pTail=NULL;/*链表尾*/

Node::Node(){

}
Node::Node(int data){
    this->data=data;
    this->next=NULL;
}

void Node::AddNode(int data){
    if (pHead==NULL) {
        pHead = new Node(data);
        pTail=pHead;
        return;
    }
    pTail->next=new Node(data);
    pTail=pTail->next;
}


void Node::AddNode(Node *node){
    if (pHead==NULL) {
        pHead=node;
        pTail=pHead;
        return;
    }
    pTail->next=node;
    pTail=pTail->next;
}
bool Node::DeleteNodes(int data){
    bool flag = false;
    
    if (pHead==NULL) {
        return flag;
    }
    
    /*遍历链表查找符合条件的节点*/
    
    Node* pTemp = pHead;
    
    if (pHead->data == data) {
        pTemp = pHead->next;
        delete pHead;
        pHead=pTemp;
        if (pHead==NULL) {
            return true;
        }
    }
    
    Node* pMove = pHead->next;
    
    while (pMove!=NULL) {
        if (pMove->data==data) {
            pTemp->next=pMove->next;//链表解链
            delete pMove;//删除解链节点
            
            pMove=pTemp->next;
        }else
        {
            /*移动迭代指针*/
            pMove=pMove->next;
            pTemp=pTemp->next;
        }
    }
    
    return flag;

}



void Node::GetNodesMessage()
{
    if (pHead==NULL) {
        printf("当前链表为空\n");
        return;
    }
    
    Node* pMove = pHead;
    while (pMove!=NULL) {
        printf("%d->",pMove->data);
        pMove=pMove->next;
    }
    printf("NULL\n");
}

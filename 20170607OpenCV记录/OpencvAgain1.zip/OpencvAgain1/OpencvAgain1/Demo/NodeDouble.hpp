//
//  NodeDouble.hpp
//  OpencvAgain1
//
//  Created by admindyn on 2017/6/7.
//  Copyright © 2017年 admindyn. All rights reserved.
//

#ifndef NodeDouble_hpp
#define NodeDouble_hpp

#include <stdio.h>

#endif /* NodeDouble_hpp */

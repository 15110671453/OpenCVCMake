//
//  ServerMacKQueue.hpp
//  OpencvAgain1
//
//  Created by admindyn on 2017/6/7.
//  Copyright © 2017年 admindyn. All rights reserved.
//

#ifndef ServerMacKQueue_hpp
#define ServerMacKQueue_hpp

#include <stdio.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>
//支持kqueue
#include <sys/event.h>
#include <sys/types.h>
#include <sys/time.h>

#include <unistd.h>

class ServerMacKQueue
{
public:
    ServerMacKQueue();
    void testKQueueServer();
};


#endif /* ServerMacKQueue_hpp */

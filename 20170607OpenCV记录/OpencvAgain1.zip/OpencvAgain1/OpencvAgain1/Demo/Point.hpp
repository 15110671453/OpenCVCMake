//
//  Point.hpp
//  OpencvAgain1
//
//  Created by admindyn on 2017/6/7.
//  Copyright © 2017年 admindyn. All rights reserved.
//

#ifndef Point_hpp
#define Point_hpp

#include <stdio.h>

class Point{
    
public:
    double x;
    double y;
    double getDistance(Point& p);
    Point(double x,double y);
    Point();

};


#endif /* Point_hpp */

//
//  SocketMac.hpp
//  OpencvAgain1
//
//  Created by admindyn on 2017/6/7.
//  Copyright © 2017年 admindyn. All rights reserved.
//

#ifndef SocketMac_hpp
#define SocketMac_hpp

#include <string.h>
#include <stdio.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>

class SocketMac{

public:
    struct sockaddr_in server_addr;
    int server_socket;
    int bind_result;
    struct sockaddr_in client_addr;
    socklen_t address_len;
    int client_socket;
    
    SocketMac();
   void readySocket();
    void upadteReplyMessage();
};

#endif /* SocketMac_hpp */
